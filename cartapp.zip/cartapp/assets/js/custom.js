window.addEventListener("load", () => {
  console.log("document load");
});
